//
//  AppDelegate.h
//  Demo
//
//  Created by RaStar on 2020/8/13.
//  Copyright © 2020 vincent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;

@end

