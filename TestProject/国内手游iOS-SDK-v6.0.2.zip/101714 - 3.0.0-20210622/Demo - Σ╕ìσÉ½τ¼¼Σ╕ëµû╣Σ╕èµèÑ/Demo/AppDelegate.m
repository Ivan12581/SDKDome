//
//  AppDelegate.m
//  Demo
//
//  Created by RaStar on 2020/8/13.
//  Copyright © 2020 vincent. All rights reserved.
//

#import "AppDelegate.h"
#import <RaStarSDK/RaStarSDK.h>

@interface AppDelegate ()



@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [[RaStarCommon sharedInstance] setUserAgent];
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return [[RaStarCommon sharedInstance] openURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(nonnull void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler{
    if (![[RaStarCommon sharedInstance] handleUniversalLink:userActivity]) {
        // 其他SDK的回调
    }
    return YES;
}

- (void)applicationWillTerminate:(UIApplication *)application{
    [[RaStarCommon sharedInstance] setCloseType];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[RaStarCommon sharedInstance] setStartType];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return [[RaStarCommon sharedInstance] application:application handleOpenURL:url];
}

@end
