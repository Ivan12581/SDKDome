//
//  ViewController.m
//  Demo
//
//  Created by RaStar on 2020/8/13.
//  Copyright © 2020 vincent. All rights reserved.
//

#import "ViewController.h"
#import "RaStarDemoCollectionViewCell.h"
#import <RaStarSDK/RaStarSDK.h>

@interface ViewController ()<RaStarInitDelegate,RaStarLoginDelegate,RaStarManagerDelegate,RaStarServiceDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,RaStarServiceDelegate>

@property (nonatomic, copy) NSArray *dataArray;

@property (weak, nonatomic) IBOutlet UICollectionView *mainCollectionView;

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //先指定代理协议
    
    //指定初始化回调协议
    [[RaStarCommon sharedInstance] addInitDelegate:self];
    //指定登陆接口协议
    [[RaStarCommon sharedInstance] addLoginDelegate:self];
    //指定支付回调协议
    [[RaStarCommon sharedInstance] addManagerDelegate:self];
    //指定客服回调协议
    [[RaStarCommon sharedInstance] addServiceDelegate:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getShareResult:) name:RaStarShareResultNotificationName object:nil];
    
    //设置dataSouce
    self.dataArray = @[@"初始化",//0
                       @"显示登录",//1
                       @"数据上报",//2
                       @"支付",//3
                       @"分享链接",//4
                       @"验证聊天",//5
                       @"手动拉起实名",//6
                       @"分享图片",//7
                       @"分享文字",//8
                       @"分享视频",//9
                       @"显示客服",//10
                       @"退出登录",//11
                       @"分享文字（无UI)",//12
                       @"分享图片（无UI）",//13
                       @"分享链接（无UI）",//14
                       @"分享视频（无UI）"//15
                        ];
    self.textView.text = @"准备就绪，请点击初始化按钮";
}
- (NSInteger)collectionView:(UICollectionView*)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGSize)collectionView:(UICollectionView*)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath*)indexPath{

    return CGSizeMake(70, 50);
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    RaStarDemoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"RaStarDemoCellID" forIndexPath:indexPath];
    cell.cellLabel.text = self.dataArray[indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
            [self registerSDK];
            break;
        case 1:
            [self showLoginViewAction];
            break;
        case 2:
            [self uploadUserInfoAction];
            break;
        case 3:
            [self payAction];
            break;
        case 4:
            [self shareURLAction];
            break;
        case 5:
            [self verifyRealNameChatAction];
            break;
        case 6:
            [self showUserVerifiedViewAction];
            break;
        case 7:
            [self shareImageAction];
            break;
        case 8:
            [self shareTextAction];
            break;
        case 9:
            [self shareVideoAction];
            break;
        case 10:
            [self serviceButtonAction];
            break;
        case 11:
            [self logoutAction];
            break;
        case 12:
            [self shareTextWithoutUIAction];
            break;
        case 13:
            [self shareImageWithoutUIAction];
            break;
        case 14:
            [self shareURLWithoutUIAction];
            break;
        case 15:
            [self shareVideoWithoutUIAction];
            break;
        default:
            break;
    }
    
    
}

#pragma mark -- 初始化
- (void)registerSDK{
    [RaStarCommon sharedInstance].useSDKAlertView = YES;
    [[RaStarCommon sharedInstance] registerSDK];
    [RaStarCommon sharedInstance].mainBackGroundColor = [UIColor clearColor];
    NSLog(@"DeviceID：%@",[RaStarCommon sharedInstance].deviceID);
}
- (void)onInitFail {
    self.textView.text = @"初始化失败";
}

- (void)onInitSuccess {
    NSLog(@"初始化成功");
    self.textView.text = @"初始化成功";
}
#pragma mark -- 登录
- (void)showLoginViewAction{
    [[RaStarCommon sharedInstance] showLoginView];
}
- (void)onCommonLoginSuccess:(NSString *)token Uid:(NSString *)uid{
    self.textView.text = [NSString stringWithFormat:@"登录成功：\nToken:%@\nUid:%@",token,uid];
}
- (void)onCommonLoginOut{
    self.textView.text = @"注销登录,请手动触发登录方法";
}
- (void)onCommonLoginFail{
    self.textView.text = @"登录失败";
}

#pragma mark -- 数据上报
- (void)uploadUserInfoAction{
    double mtm = [[NSDate date] timeIntervalSince1970] * 1000;
    NSLog(@"角色时间戳单位毫秒传整数mtm --- %.0f",mtm);
    [[RaStarCommon sharedInstance] uploadUserRoleCreateRoleTime:mtm Action:RSUserActionType_EnterServer RoleID:@"RoleIDIDID" RoleName:@"usfgwu  *(%&@#&%@" RoleLevel:10086 ServerID:@"serverID" ServerName:@"Server Name @#$*" RealServerName:@"Real Name %2d" RealServerID:@"realServerID" Vip:1 PartyName:@"nil"];
}
#pragma mark -- 支付
- (void)payAction{
    NSDate * datenow = [NSDate date];
    NSString * timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970] + arc4random() % 100000];
    
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Shop" message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addTextFieldWithConfigurationHandler:nil];
    alert.textFields.firstObject.placeholder = @"金额";
    [alert addTextFieldWithConfigurationHandler:nil];
    alert.textFields.lastObject.placeholder = @"商品";
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSString *money = alert.textFields.firstObject.text;
        NSString *product = alert.textFields.lastObject.text;
        [[RaStarCommon sharedInstance] managerWithAmount:money andName:@"美国队长" andLevel:@"999" andRoleid:@"113" andSid:@"123456" andSname:@"测试服" andSubject:product andOrder_no:timeSp andExt:@"111"];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)onManagerState:(RSManagerResultCode)RSManagercode{
    self.textView.text = [NSString stringWithFormat:@"%ld",(long)RSManagercode];
}

#pragma mark -- 验证实名聊天
- (void)verifyRealNameChatAction{
    [[RaStarCommon sharedInstance] getUserVerifiedInfo:^(int code) {
        self.textView.text = [NSString stringWithFormat:@"聊天状态代码为：%ld",(long)code];
    }];
}
#pragma mark -- 手动拉起实名认证
- (void)showUserVerifiedViewAction{
    [[RaStarCommon sharedInstance] showUserVerifiedView:^(BOOL verifiedType) {
        NSString *type = @"认证失败！";
        if (verifiedType) {
            type = @"认证成功！";
        }
        self.textView.text = type;
    }];
}
#pragma mark -- 分享链接
- (void)shareURLAction{
    [[RaStarCommon sharedInstance] shareWithTitle:@"分享标题" Message:@"分享内容" Image:[UIImage imageNamed:@"testImage"] ShareUrl:@"https://www.rastargame.com"];
}
- (void)shareURLWithoutUIAction{
    [[RaStarCommon sharedInstance] shareWithTitle:@"分享标题" Message:@"分享内容" Image:[UIImage imageNamed:@"testImage"] ShareUrl:@"https://www.rastargame.com" ShareType:RSShareType_QQ];
}
#pragma mark -- 分享文字
- (void)shareTextAction{
    [[RaStarCommon sharedInstance] shareWithMessage:nil];
}
- (void)shareTextWithoutUIAction{
    [[RaStarCommon sharedInstance] shareWithMessage:@"分享的文字" ShareType:RSShareType_QZone];
}
#pragma mark -- 分享图片
- (void)shareImageAction{
    [[RaStarCommon sharedInstance] shareWithImage:[UIImage imageNamed:@"testImage"]];
}
- (void)shareImageWithoutUIAction{
    [[RaStarCommon sharedInstance] shareWithImage:[UIImage imageNamed:@"testImage"] ShareType:RSShareType_WeChat];
}
#pragma mark -- 分享视频
- (void)shareVideoAction{
    [[RaStarCommon sharedInstance] shareWithVideoTitle:@"这个是标题" Message:@"这个是描述" VideoURL:@"http://video.sina.com.cn/p/sports/2020-01-15/detail-iihnKzhha2647094.d.html"];
}
- (void)shareVideoWithoutUIAction{
    [[RaStarCommon sharedInstance] shareWithVideoTitle:@"这个是标题" Message:@"这个是描述" VideoURL:@"http://video.sina.com.cn/p/sports/2020-01-15/detail-iihnKzhha2647094.d.html" ShareType:RSShareType_TimeLine];
}
#pragma mark -- 展示客服界面
-(void)serviceButtonAction{
    [[RaStarCommon sharedInstance] showService];
}
-(void)serviceClose{
    NSLog(@"关闭客服界面");
}

- (void)callBackServiceIssueSubmitWithMsgDict:(NSDictionary *)msgDict {
    
    NSLog(@"收到客服回调 --- %@",msgDict);
    
    
    
    /*
     
     返回一个字典数据 对应key value 值如下：
     openid   对应返回openid
     role_id 对应返回角色ID
     question_title 对应返回问题标题
     question_desc 对应返回问题描述
     image_url 图片地址数组 可能为空数组 研发拿数组值前先判断数组元素 避免发生不必要的闪退

     */
    NSLog(@"openid --- %@",[NSString stringWithFormat:@"%@",msgDict[@"openid"]]);
    NSLog(@"角色ID role_id --- %@",[NSString stringWithFormat:@"%@",msgDict[@"role_id"]]);
    NSLog(@"问题标题 --- %@",[NSString stringWithFormat:@"%@",msgDict[@"question_title"]]);
    NSLog(@"问题描述 --- %@",[NSString stringWithFormat:@"%@",msgDict[@"question_desc"]]);

    NSString *openid = [NSString stringWithFormat:@"%@",msgDict[@"openid"]];
    NSString *role_id = [NSString stringWithFormat:@"%@",msgDict[@"role_id"]];
    NSString *question_title = [NSString stringWithFormat:@"%@",msgDict[@"question_title"]];
    NSString *question_desc = [NSString stringWithFormat:@"%@",msgDict[@"question_desc"]];
    NSArray *image_url = msgDict[@"image_url"];
    
    NSLog(@"图片数组中有 --- %ld个元素",image_url.count);
    
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"客服提单信息" message:[NSString stringWithFormat:@"openid:%@ role_id:%@ question_title:%@ question_desc:%@ image_url:%@",openid,role_id,question_title,question_desc,image_url] preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"关闭");
    }];
    
    [alertC addAction:sureAction];
    [self presentViewController:alertC animated:YES completion:nil];
}
#pragma mark -- 退出登录
- (void)logoutAction{
    [[RaStarCommon sharedInstance] loginViewOut];
}
#pragma mark -- 分享结果
- (void)getShareResult:(NSNotification *)notification{
    self.textView.text = notification.object[@"message"];
}
@end
